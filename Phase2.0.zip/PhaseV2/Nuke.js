const { Client, GatewayIntentBits } = require('discord.js');
const { ChannelType } = require('discord.js');
const fs = require('fs');
const readline = require('readline');
const path = require('path');

const settingsFile = path.join(__dirname, 'misc', 'settings.json');

// Setup readline for user input
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function askQuestion(query) {
    return new Promise(resolve => rl.question(query, answer => resolve(answer)));
}

async function getSettings() {
    if (fs.existsSync(settingsFile)) {
        const savedSettings = JSON.parse(fs.readFileSync(settingsFile, 'utf8'));
        console.log('Saved settings found:');
        console.log(savedSettings);
        const useSaved = await askQuestion('Use saved settings? (yes/no): ');
        if (useSaved.toLowerCase().startsWith('y')) {
            return savedSettings;
        }
    }

    const botToken = await askQuestion('Enter your Bot Token: ');
    const guildId = await askQuestion('Enter your Guild ID: ');
    const message = await askQuestion('Enter the message to send: ');
    const channelName = await askQuestion('Enter the channel name: ');

    const newSettings = { botToken, guildId, message, channelName };

    if (!fs.existsSync(path.join(__dirname, 'misc'))) {
        fs.mkdirSync(path.join(__dirname, 'misc'));
    }

    fs.writeFileSync(settingsFile, JSON.stringify(newSettings, null, 4));
    console.log('Settings saved to /misc!');
    return newSettings;
}

(async () => {
    const settings = await getSettings();
    rl.close();

    const client = new Client({
        intents: [GatewayIntentBits.Guilds]
    });

    let createdChannels = [];
    let guild = null;
    let channelCount = 0;

    async function sendMessageToChannels(guild, channelIds, message) {
        for (const channelId of channelIds) {
            const channel = guild.channels.cache.get(channelId);
            if (channel && channel.isTextBased()) {
                try {
                    await channel.send(`@everyone ${message}`);
                    console.log(`Message sent to channel ${channel.name} (ID: ${channel.id})`);
                } catch (error) {
                    console.error(`Failed to send message to channel ${channel.name} (ID: ${channel.id}): ${error.message}`);
                }
            } else {
                console.log(`Channel with ID ${channelId} is not text-based or does not exist.`);
            }
        }
    }

    function createChannel(guild) {
        const channelOptions = {
            name: settings.channelName,
            type: ChannelType.GuildText,
            topic: 'skibidi nuke',
            nsfw: false,
            position: null,
            rateLimitPerUser: 5,
            permissionOverwrites: [
                {
                    id: guild.id,
                    deny: ['SendMessages'],
                },
            ],
        };

        guild.channels.create(channelOptions)
            .then((newChannel) => {
                console.log(`Channel created: ${newChannel.name} (ID: ${newChannel.id})`);
                createdChannels.push(newChannel.id);
                sendMessageToChannels(guild, createdChannels, settings.message);
                createdChannels = [];
                channelCount++;
                console.log(`Total channels created: ${channelCount}`);
            })
            .catch((error) => {
                console.error('An error occurred while creating the channel:', error);
            });
    }

    client.once('ready', async () => {
        try {
            console.log(`Logged in as ${client.user.tag}`);
            guild = client.guilds.cache.get(settings.guildId);

            if (!guild) {
                console.log('Server with the provided ID does not exist or the bot has no access.');
                return;
            }

            const channelIds = (await guild.channels.fetch()).map(channel => channel.id);
            console.log(channelIds);

            setInterval(() => {
                createChannel(guild);
            }, 100);

        } catch (err) {
            console.error('An error occurred:', err);
        }
    });

    client.login(settings.botToken);
})();
